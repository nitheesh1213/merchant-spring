package com.addMerchant.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.addMerchant.bean.AddMerchant;
import com.addMerchant.service.IAddMerchantService;
import com.product.exception.ProductException;
@CrossOrigin("http://localhost:4200")
@RestController
public class AddMerchantController {
	@Autowired
	IAddMerchantService addMerchantService;
	
	@RequestMapping(value="/AddMerchant", method=RequestMethod.POST)
	public void addMerchant(@RequestBody AddMerchant merchant) throws ProductException{
	addMerchantService.addMerchant(merchant);
			}
}