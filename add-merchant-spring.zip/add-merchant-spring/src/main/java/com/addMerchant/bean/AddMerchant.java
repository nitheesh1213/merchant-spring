package com.addMerchant.bean;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;


@Entity
public class AddMerchant implements Serializable {


	@Id
	@GeneratedValue
	private int id;
	private String mname;
	private long mmobile;
	private String mmail;
	private String maddress;
	
	
	public String getMname() {
		return mname;
	}
	public void setMname(String mname) {
		this.mname = mname;
	}
	public long getMmobile() {
		return mmobile;
	}
	public void setMmobile(long mmobile) {
		this.mmobile = mmobile;
	}
	public String getMmail() {
		return mmail;
	}
	public void setMmail(String mmail) {
		this.mmail = mmail;
	}
	public String getMaddress() {
		return maddress;
	}
	public void setMaddress(String maddress) {
		this.maddress = maddress;
	}
	
	
	
	@Override
	public String toString() {
		return "AddMerchant [mname=" + mname + ", mmobile=" + mmobile + ", mmail=" + mmail + ", maddress=" + maddress
				+ "]";
	}
	

}
