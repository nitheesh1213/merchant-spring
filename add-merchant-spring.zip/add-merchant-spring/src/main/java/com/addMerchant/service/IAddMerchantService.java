package com.addMerchant.service;

import java.util.List;

import com.addMerchant.bean.AddMerchant;
import com.product.exception.ProductException;

public interface IAddMerchantService {

	public void addMerchant(AddMerchant merchant) throws ProductException;
	//public AddMerchant getProductById(String id) throws ProductException;
	//public void deleteProduct (String id) throws ProductException;
	//public List<AddMerchant> getAllProducts() throws ProductException;
	//public List<AddMerchant> updateProduct(String id, AddMerchant product) throws ProductException;
	
	
}
