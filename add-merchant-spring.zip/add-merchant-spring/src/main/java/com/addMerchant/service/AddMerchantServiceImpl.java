package com.addMerchant.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.addMerchant.bean.AddMerchant;
import com.addMerchant.dao.AddMerchantDao;
import com.product.exception.ProductException;

@Service
public class AddMerchantServiceImpl implements IAddMerchantService {
	@Autowired
	AddMerchantDao productDao;	
	
//	@Override
//	public List<AddMerchant> createProduct(AddMerchant product) throws ProductException {
//		try {
//			 productDao.save(product);
//		        return productDao.findAll();
//		        }catch(Exception exception) {
//		            throw new ProductException(exception.getMessage());
//		        }
//	}

	@Override
	public void addMerchant(AddMerchant merchant) throws ProductException {
		try {
			 productDao.save(merchant);
		        }catch(Exception exception) {
		            throw new ProductException(exception.getMessage());
		        }
	}

//	@Override
//	public void deleteProduct(String id) throws ProductException {
//		try
//		{
//			productDao.deleteById(id);
//			
//		}
//		catch(Exception exception)
//		{
//			throw new ProductException(exception.getMessage());
//		}
//		
//	}
//	
//	@Override
//	public List<AddMerchant> getAllProducts() throws ProductException {
//		try
//		{
//			return productDao.findAll();
//		}
//		catch(Exception exception)
//		{
//			throw new ProductException(exception.getMessage());
//		}
//	}
//	
//	@Override
//	public AddMerchant getProductById(String id) throws ProductException {
//		try
//		{
//			return productDao.findById(id).get();
//		}
//		catch (Exception exception)
//		{
//			throw new ProductException(exception.getMessage());
//		}
//		
//	}
//
//	@Override
//	public List<AddMerchant> updateProduct(String id, AddMerchant product1) throws ProductException {
//		try
//		{
//			Optional<AddMerchant> optional=productDao.findById(id);
//			if(optional.isPresent())
//			{
//				AddMerchant product=optional.get();
//				product.setName(product1.getName());
//				product.setModel(product1.getModel());
//				product.setPrice(product1.getPrice());
//				productDao.save(product);
//				return getAllProducts();
//			}
//			else
//			{
//				throw new ProductException("Product with"+id+" not exist");	
//			}
//		}
//			catch(Exception exception) {
//	            throw new ProductException(exception.getMessage());
//			
//	}
//	}
}



